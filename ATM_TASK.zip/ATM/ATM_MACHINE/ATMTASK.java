package ATM_MACHINE;

public class ATMTASK {
    public static void main(String[] args) {
        // Create an instance of Account
        Account account = new Account(1000); // Initial balance

        // Create an instance of ATM with the account
        ATM atm = new ATM(account);

        // Start ATM operations
        atm.start();
    }
}

