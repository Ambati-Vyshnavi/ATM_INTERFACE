package ATM_MACHINE;
import java.util.Scanner;

// ATM class implementing UserAuthentication interface
class ATM implements UserAuthentication {
    private Account account;
    public int userId = 1234;
    public int pin = 456;

    // Constructor
    public ATM(Account account) {
        this.account = account;
    }

    @Override
    public boolean authenticateUser(int userId, int pin) {
        if (this.userId == userId & this.pin == pin) {
            return true;
        } else {
            return false;
        }
    }

    // Method to start ATM operations
    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM");
        System.out.print("Enter your user ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter your PIN: ");
        int pin = scanner.nextInt();

        if (authenticateUser(userId, pin)) {
            if (authenticateUser(userId, pin)) {

                int choice;
                do {
                    System.out.println("\nATM Menu:");
                    System.out.println("1. View Transactions History");
                    System.out.println("2. Withdraw");
                    System.out.println("3. Deposit");
                    System.out.println("4. Transfer");
                    System.out.println("5. Quit");
                    System.out.print("Enter your choice: ");
                    choice = scanner.nextInt();

                    switch (choice) {
                        case 1 : account.viewTransactionsHistory();
                            break;
                        case 2:
                            System.out.print("Enter amount to withdraw: ");
                            double withdrawAmount = scanner.nextDouble();
                            account.withdraw(withdrawAmount);
                            break;
                        case 3:
                            System.out.print("Enter amount to deposit: ");
                            double depositAmount = scanner.nextDouble();
                            account.deposit(depositAmount);
                            break;
                        case 4:
                            System.out.print("Enter amount to transfer: ");
                            double transferAmount = scanner.nextDouble();
                            scanner.nextLine();
                            System.out.print("Enter recipient account: ");
                            String recipientAccount = scanner.nextLine();
                            account.transfer(transferAmount, recipientAccount);
                            break;
                        case 5:
                            System.out.println("Exiting ATM. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                            break;
                    }
                } while (choice != 5);
            } else {
                System.out.println("Authentication failed. Please try again.");
            }


        }
    }
}
