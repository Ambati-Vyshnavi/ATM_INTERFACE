package ATM_MACHINE;
import java.util.ArrayList;
import java.util.List;

// Base class for Account
class Account implements ATM_INTERFACE {
    private double balance;
    private List<String> transactionsHistory;

    // Constructor
    public Account(double initialBalance) {
        this.balance = initialBalance;
        this.transactionsHistory = new ArrayList<>();
    }

    @Override
    public void viewTransactionsHistory() {
        System.out.println("Transactions History:");
        for (String transaction : transactionsHistory) {
            System.out.println(transaction);
        }
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactionsHistory.add("Withdrawal: -$" + amount);
            System.out.println("Withdrawal successful. Current balance: $" + balance);
        } else {
            System.out.println("Invalid amount or insufficient balance.");
        }
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactionsHistory.add("Deposit: +$" + amount);
            System.out.println("Deposit successful. Current balance: $" + balance);
        } else {
            System.out.println("Invalid amount.");
        }
    }

    @Override
    public void transfer(double amount, String recipientAccount) {
        // For simplicity, assume transfer is successful without any validations
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactionsHistory.add("Transfer to " + recipientAccount + ": -$" + amount);
            System.out.println("Transfer successful. Current balance: $" + balance);
        } else {
            System.out.println("Invalid amount or insufficient balance.");
        }
    }
}
