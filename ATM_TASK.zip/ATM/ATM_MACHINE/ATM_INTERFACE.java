package ATM_MACHINE;
// Interface for Account operations
interface ATM_INTERFACE {
    void viewTransactionsHistory();
    void withdraw(double amount);
    void deposit(double amount);
    void transfer(double amount, String recipientAccount);
}

// Interface for User Authentication
interface UserAuthentication {
    boolean authenticateUser(int userId, int pin);
}

